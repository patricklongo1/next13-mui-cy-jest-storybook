/* eslint-disable @typescript-eslint/no-var-requires */
const matchers = require('jest-extended')
expect.extend(matchers)

afterEach(() => {
  jest.useRealTimers()
})
