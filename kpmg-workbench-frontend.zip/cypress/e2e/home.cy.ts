// cypress/integration/form.spec.js
describe('should send form with valid data', () => {
  /* beforeEach(() => {
    cy.visit('/schedule')
  }) */

  it('should fill the form and submit', () => {
    cy.visit('/')
  })
})
