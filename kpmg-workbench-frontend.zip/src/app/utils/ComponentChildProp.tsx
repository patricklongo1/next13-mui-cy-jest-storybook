import { ReactNode } from 'react'

export interface ComponentChildProp {
  children: ReactNode
}
